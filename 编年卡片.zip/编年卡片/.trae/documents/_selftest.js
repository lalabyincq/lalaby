/* 临时自测：注入库内真实 6 张卡片（2026-09-20 快照），验证解析/索引/渲染/交互。验证完随文件删除。 */
(function(){
  const FIX = [
    {path:"卡片/编年/-3000-埃及/卡片.md", txt:
"---\n年份: -3000\n地点: 埃及\n别名: []\n系列:\n  - 编年卡片\n标签: []\n---\n\n# 概述\n\n（待补：这张卡片最突出的面貌）\n\n## 政治\n\n\n\n## 经济\n\n\n\n## 社会\n\n\n\n## 科技\n\n\n\n## 日常生活\n\n\n\n## 艺术\n\n\n\n## 关系\n\n（待补：与其他卡片的双链）\n\n## 来源\n\n（待补）\n"},
    {path:"卡片/编年/1200-杭州/卡片.md", txt:
"---\n年份: 1195-1205\n地点: 杭州\n别名: [临安, 南宋行在]\n系列: [编年卡片]\n标签: [商业化城市, 官僚制, 禅宗, 稻作农业, 市民文化, 印刷术]\n---\n\n# 概述\n\n南宋行在，人口逾百万的当时世界最大城市之一。政治中心与商业中心重合，市民文化极度繁荣。\n\n## 政治\n\n君主官僚制成熟期：科举出身的文官集团主导朝政。\n\n## 经济\n\n纸币（会子）已为主要流通货币。瓦舍勾栏、酒楼茶肆构成庞大的服务业经济。\n\n## 社会\n\n科举使阶层流动通道制度化，城市平民成为显著群体，行会组织发达。\n\n## 科技\n\n活字印刷已发明但雕版仍为主流，官私刻书业极盛，指南针已用于航海。\n\n## 日常生活\n\n主食稻米，市面百味小食。市民午后听平话、看傀儡戏，夜有瓦子百戏。\n\n## 艺术\n\n院体画与文人画并立；山水从全景转向边角构图。\n\n![西湖图](图/1200-杭州-西湖图-李嵩.jpg)\n> 李嵩《西湖图》可见湖上画舫与环湖寺院，反映游赏之盛。\n\n## 关系\n\n- 参见 [[1700-阿姆斯特丹]]：同样高度商业化、印刷业发达、市民文化兴盛的口岸城市。\n\n## 来源\n\n- 《梦粱录》吴自牧，卷十三、卷十六\n- 《武林旧事》周密\n"},
    {path:"卡片/编年/1700-阿姆斯特丹/卡片.md", txt:
"---\n年份: 1695-1705\n地点: 阿姆斯特丹\n别名: []\n系列: [编年卡片]\n标签: [商业化城市, 行会, 信贷, 印刷术, 市民文化, 全球贸易]\n---\n\n# 概述\n\n荷兰共和国的商贸心脏，当时欧洲的金融与出版中心。由商人寡头治理的城邦式共和国。\n\n## 政治\n\n没有君主：城市由摄政阶层通过市政会治理，省联议会协商决策。言论环境相对宽松。\n\n## 经济\n\n阿姆斯特丹银行（1609）与证券交易所使信贷票据取代大量现金流通，为近代金融体系雏形。东印度公司垄断东方香料贸易。\n\n## 社会\n\n商人阶层居于社会顶端。大量外来移民构成人口的多数来源。\n\n## 科技\n\n显微镜（列文虎克）与天文观测在此领先；制图学世界一流。雕版与活字并举。\n\n## 日常生活\n\n早餐黑麦面包配奶酪与鲱鱼；住宅窄而深，沿运河排布。室内大量悬挂静物与风景画。\n\n## 艺术\n\n伦勃朗晚年、风俗画黄金期。花卉静物画盛行，郁金香狂热（1637）余波未消。\n\n## 关系\n\n- 参见 [[1200-杭州]]：同为印刷业与市民消费文化高度发达的商业都会。\n\n## 来源\n\n- Schama, S. *The Embarrassment of Riches*\n"},
    {path:"卡片/交互/1966-ELIZA/卡片.md", txt:
"---\n年份: 1966\n地点: 麻省理工学院\n对象: ELIZA\n范式: 对话式交互\n系列: [交互设计]\n标签: [对话式交互, 拟人化, 聊天机器人, 图灵测试]\n---\n\n# 概述\n\nWeizenbaum 用模式匹配模拟心理治疗师的程序，是“用自然语言对话操作机器”的第一次大众化演示。\n\n## 技术基础\n\n无任何“理解”：关键词匹配 + 模板改写。算力需求极小，却制造了理解力极强的错觉。\n\n## 交互隐喻\n\n“对话即界面”：说人话即可。这个话术五十八年后仍是大语言模型的基本盘。\n\n## 美学风格\n\n终端绿字、逐字打印的延迟感——等待也是体验的一部分。\n\n## 用户群体\n\n秘书与来访者自发对其倾诉，即“ELIZA 效应”。\n\n## 商业模式\n\n无商业化，学术项目。\n\n## 争议与批评\n\nWeizenbaum 本人转而批判人工智能，成为人机交互伦理学的起点。\n\n## 关系\n\n- 参见 [[2007-iPhone]]：手势直接操纵与语言对话是交互的两个极点。\n- 参见 [[1200-杭州]]：说书人瓦舍与聊天机器人共享同一种古老技术。\n\n## 来源\n\n- Weizenbaum, J. “ELIZA” (1966)；《计算机能力与人类理性》1976\n"},
    {path:"卡片/交互/2007-iPhone/卡片.md", txt:
"---\n年份: 2007\n对象: iPhone\n范式: 多点触控 GUI\n系列: [交互设计]\n标签: [直接操纵, 拟物化, 封闭生态, 应用商店, 手势]\n---\n\n# 概述\n\n用“手指直接碰内容”取代了笔尖和按键，把“电话+音乐+上网”三合一的故事讲成了一种全新的人机关系。\n\n## 技术基础\n\n电容式多点触控屏 + 精简版 macOS 的算力冗余，使双指捏合成为可能。\n\n## 交互隐喻\n\n核心隐喻是“一叠可以拨动的卡片”：内容即界面，控件尽量消失。\n\n## 美学风格\n\n拟物化的顶点与转折点；界面美学围绕“内容全屏化”重组。\n\n## 用户群体\n\n首发高端极客，两年内借助 App Store 下沉为大众品。\n\n## 商业模式\n\n卖硬件 + 运营商分成 + 应用商店抽成三成。\n\n## 争议与批评\n\n封闭生态自始即被批评；触屏状态不可见成为可用性争论的源头。\n\n## 关系\n\n- 参见 [[1966-ELIZA]]：对话式交互的另一极。\n- 参见 [[1200-杭州]]：应用商店之于交互创意，恰如书坊之于话本。\n\n## 来源\n\n- iPhone 发布会 Keynote（2007-01-09）\n"},
    {path:"卡片/梵高研究/1888-阿尔勒-夜间咖啡馆/卡片.md", txt:
"---\n年份: 1888\n地点: 阿尔勒\n对象: 夜间咖啡馆\n时期: 阿尔勒时期\n系列: [梵高研究]\n标签: [互补色, 夜景, 日本主义, 颜料厚涂, 反透视]\n---\n\n# 概述\n\n梵高在阿尔勒画的室内夜景，用刺目的色彩关系做“情绪武器”的宣言式作品。\n\n## 构图与笔触\n\n反透视：天花板绿光把空间压扁，视线被逼向右后方挂钟。笔触粗、快、短。\n\n## 色彩策略\n\n红与绿的互补对撞是全画的发动机。色彩直接承担心理功能。\n\n## 题材与动机\n\n画的是火车站旁通宵营业的咖啡馆。为筹备“南方画室”期间的系列室内画之一。\n\n## 心理与书信\n\n同期失眠严重；三个月后高更抵达，年末发生割耳事件。\n\n## 技法实验\n\n粗笔厚涂；学习日本主义以轮廓线和平涂组织画面。\n\n## 后世影响\n\n成为表现主义“色彩即情绪”的先声参考；原作现藏耶鲁大学美术馆。\n\n## 关系\n\n- 参见 [[1200-杭州]]：日本浮世绘绕道巴黎改变了欧洲绘画。\n- 参见 [[1700-阿姆斯特丹]]：荷兰绘画传统在他身上的底色与出走。\n\n## 来源\n\n- 《梵高书信全集》第 676、677 号信；Yale 藏品档案\n"}
  ];

  source = { type:"local" };
  knownImages = new Set();
  localImgHandles = new Map();
  ingest(FIX);
  renderHome();
  show("homeView");
  document.getElementById("emptyView").style.display = "none";
  document.getElementById("srcStatus").textContent = "自测数据（6 张真实卡片）";
  document.getElementById("srcStatus").classList.add("on");

  const R = [];
  const check = (name, cond, extra) => R.push((cond ? "PASS" : "FAIL") + "｜" + name + (extra ? "｜" + extra : ""));
  const bySlug = s => cards.find(c => c.slug === s);

  check("卡片总数=6", cards.length === 6, "实际 " + cards.length);
  check("年份升序", cards.map(c=>c.slug).join(",") === "-3000-埃及,1200-杭州,1700-阿姆斯特丹,1888-阿尔勒-夜间咖啡馆,1966-ELIZA,2007-iPhone", cards.map(c=>c.slug).join(","));
  check("yearKey 解析（负年/区间）", JSON.stringify(cards.map(c=>c.yearKey)) === "[-3000,1195,1695,1888,1966,2007]", JSON.stringify(cards.map(c=>c.yearKey)));
  const bl = (backlinks["1200-杭州"]||[]).map(c=>c.slug).sort();
  check("杭州反链=4", bl.length === 4, bl.join("、"));
  const broken = [];
  for (const c of cards) for (const sl of c.links) if (!slugIndex[sl]) broken.push(c.slug + "→" + sl);
  check("断链=0", broken.length === 0, broken.join("；"));
  const hz = bySlug("1200-杭州");
  check("杭州缺图=1（西湖图）", hz.missingImgs.length === 1 && /西湖图-李嵩/.test(hz.missingImgs[0]), hz.missingImgs.join(","));
  const eg = bySlug("-3000-埃及");
  check("埃及待补≥8", eg.placeholders.length >= 8, eg.placeholders.join("、"));
  check("block 风格 YAML 系列解析", eg.series.join() === "编年卡片", eg.series.join());
  check("flow 风格标签解析", hz.tags.length === 6, hz.tags.join("、"));
  check("书架渲染 6 张", document.querySelectorAll("#cardGrid .pcard").length === 6);
  const artHtml = mdHtml(hz.sections.find(s=>s.title==="艺术").body, hz);
  check("艺术节渲染 figure", artHtml.indexOf("<figure>") >= 0 && /可见湖上画舫/.test(artHtml));
  check("缺图 img 带 missing 类", /class="lazyimg missing"/.test(artHtml));
  openCard(hz.uid);
  check("阅读页正文双链=1（反链另计）", document.querySelectorAll("#readerBox .wikilink[data-slug]:not(.backlink)").length === 1, document.querySelectorAll("#readerBox .wikilink[data-slug]:not(.backlink)").length + "");
  check("阅读页反链=4", document.querySelectorAll("#readerBox .backlinks .wikilink").length === 4);
  document.querySelector('#readerBox .wikilink[data-slug="1700-阿姆斯特丹"]').click();
  check("点双链跳到阿姆", document.querySelector("#readerBox h2").textContent === "1700-阿姆斯特丹");

  // 筛选：搜索
  goHome();
  const si = document.getElementById("searchInput");
  si.value = "ELIZA"; si.dispatchEvent(new Event("input"));
  check("搜索 ELIZA 命中 2（ELIZA 卡 + 链接它的 iPhone 卡）", document.querySelectorAll("#cardGrid .pcard").length === 2, document.querySelectorAll("#cardGrid .pcard").length + "");
  si.value = "会子"; si.dispatchEvent(new Event("input"));
  check("搜索 会子 命中 1（仅杭州）", document.querySelectorAll("#cardGrid .pcard").length === 1);
  si.value = ""; si.dispatchEvent(new Event("input"));
  // 标签交集
  fTags = new Set(["印刷术","商业化城市"]); renderHome();
  check("标签交集 印刷术∩商业化城市=2", document.querySelectorAll("#cardGrid .pcard").length === 2);
  fTags = new Set(); renderHome();

  // 对比：勾选杭州+阿姆（年序第2、3张）
  const boxes = document.querySelectorAll("#cardGrid .cmp");
  boxes[1].click(); boxes[2].click();
  check("对比按钮启用", document.getElementById("cmpGoBtn").disabled === false);
  document.getElementById("cmpGoBtn").click();
  check("对比页按维度对齐≥7行", document.querySelectorAll("#cmpBox .cmprow").length >= 7, document.querySelectorAll("#cmpBox .cmprow").length + " 行");
  goHome();

  const banner = document.createElement("div");
  banner.id = "testout";
  banner.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:999;background:#fffbe6;border-bottom:2px solid #d8a800;padding:8px 12px;font:12px Consolas,monospace;white-space:pre-wrap;max-height:40vh;overflow:auto;";
  banner.textContent = R.join("\n");
  document.body.appendChild(banner);
  window.__test = { R, pass: R.filter(x=>x.startsWith("PASS")).length, fail: R.filter(x=>x.startsWith("FAIL")).length };
})();
