
"use strict";

/* ================= 状态 ================= */
let source = null;                 // {type:"local", root} | {type:"gh"}
let cards = [];                    // 解析后的卡片
let slugIndex = {};                // slug -> card（uid=path）
let backlinks = {};                // slug -> [card...]
let knownImages = new Set();       // 库内实际存在的图片路径（root 相对 / 含 GitHub 库内根目录）
let localImgHandles = new Map();   // 本地：路径 -> FileHandle
let imgUrlCache = new Map();       // 路径 -> objectURL

let fSeries = "全部";
let fTags = new Set();
let chosen = new Set();            // 对比所选 uid
let curReaderUid = null;

/* ================= 小工具 ================= */
const $ = id => document.getElementById(id);
function esc(s){ return String(s == null ? "" : s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function escAttr(s){ return esc(s).replace(/"/g,"&quot;"); }
function setMsg(s){ $("loadMsg").textContent = s || ""; }

/* ================= GitHub 配置（与录入卡片共用 nb-gh） ================= */
let gh = { repo:"", branch:"main", base:"编年卡片", token:"" };
try { Object.assign(gh, JSON.parse(localStorage.getItem("nb-gh") || "{}")); } catch(e){}
function fillGhForm(){
  $("ghRepo").value = gh.repo || "";
  $("ghBranch").value = gh.branch || "main";
  $("ghBase").value = gh.base || "";
  $("ghToken").value = gh.token || "";
  $("ghSummary").textContent = gh.repo ? "GitHub 主库：" + gh.repo : "GitHub 主库（未配置）";
}
function ghStatus(m, ok){ const el=$("ghStatus"); el.textContent=m||""; el.style.color = ok===false ? "var(--warn)" : "var(--ok)"; }
function ghHeaders(){ return { "Authorization":"Bearer "+gh.token, "Accept":"application/vnd.github+json" }; }
function ghApiUrl(p){ return "https://api.github.com/repos/" + gh.repo + "/contents/" + p.split("/").map(encodeURIComponent).join("/"); }
function ghRawUrl(p){ return "https://raw.githubusercontent.com/" + gh.repo + "/" + (gh.branch||"main") + "/" + p.split("/").map(encodeURIComponent).join("/"); }
async function ghGetText(path){
  const res = await fetch(ghApiUrl(path), { headers: ghHeaders() });
  if (!res.ok) throw new Error("GitHub 读取失败 " + res.status);
  const j = await res.json();
  const bin = atob((j.content||"").replace(/\n/g,""));
  const bytes = new Uint8Array(bin.length);
  for (let i=0;i<bin.length;i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

/* ================= 解析层 ================= */
/* 年份排序键：取首个整数（支持负年）；"N世纪" -> (N-1)*100。纯投影层启发式，不回写数据 */
function yearKey(y){
  if (!y) return null;
  let m = String(y).match(/(-?\d+)\s*世纪/);
  if (m) return (parseInt(m[1],10) - 1) * 100;
  m = String(y).match(/-?\d+/);
  return m ? parseInt(m[0],10) : null;
}
function isPlaceholder(txt){
  const t = (txt||"").trim();
  return !t || t.indexOf("待补") >= 0 || t.indexOf("待完善") >= 0;
}
function parseCard(txt, path){
  const card = {
    path, uid: path,
    fsDir: path.replace(/\/卡片\.md$/, ""),
    repoDir: path.replace(/\/卡片\.md$/, ""),
    slug: path.split("/").slice(-2,-1)[0] || "",
    fields: {}, arrays: {}, tags: [], series: [], update: "",
    overview: "", sections: [], links: [], imgRefs: [],
    placeholders: [], yearKey: null
  };
  const ym = txt.match(/^---\r?\n([\s\S]*?)\r?\n---/);
  if (ym){
    let key = null;
    for (const line of ym[1].split(/\r?\n/)){
      const li = line.match(/^\s+-\s*(.*)$/);
      if (li && key){ (card.arrays[key] = card.arrays[key] || []).push(li[1].trim()); continue; }
      const kv = line.match(/^([^:#]+):\s*(.*)$/);
      if (!kv) continue;
      key = kv[1].trim();
      const v = kv[2].trim();
      const fm = v.match(/^\[(.*)\]$/);
      if (fm) card.arrays[key] = fm[1].split(",").map(s=>s.trim()).filter(Boolean);
      else card.fields[key] = v;
    }
  }
  card.tags = card.arrays["标签"] || [];
  card.series = card.arrays["系列"] || [];
  card.update = card.fields["更新"] || "";
  card.yearKey = yearKey(card.fields["年份"]);

  const body = ym ? txt.slice(ym[0].length) : txt;
  const buf = {}; const order = []; let cur = null;
  for (const line of body.split(/\r?\n/)){
    const h = line.match(/^#{1,2}\s+(.+?)\s*$/);
    if (h){ cur = h[1]; if (!(cur in buf)){ buf[cur]=""; order.push(cur);} }
    else if (cur) buf[cur] += line + "\n";
  }
  card.overview = (buf["概述"]||"").trim();
  for (const t of order){
    if (t === "概述") continue;
    const b = (buf[t]||"").trim();
    card.sections.push({ title:t, body:b, placeholder:isPlaceholder(b) });
    if (isPlaceholder(b)) card.placeholders.push(t);
  }
  if (isPlaceholder(card.overview)) card.placeholders.unshift("概述");

  const linkRe = /\[\[([^\[\]|]+?)(?:\|[^\]]+)?\]\]/g; let m;
  const whole = card.overview + "\n" + card.sections.map(s=>s.body).join("\n");
  while ((m = linkRe.exec(whole))) { const sl = m[1].trim(); if (!card.links.includes(sl)) card.links.push(sl); }
  const imgRe = /!\[[^\]]*\]\(([^)]+)\)/g;
  while ((m = imgRe.exec(whole))) {
    let p = m[1].trim();
    if (p.indexOf("://") >= 0) continue;               // 网络图不管
    p = p.replace(/^\.\//, "");
    if (!card.imgRefs.includes(p)) card.imgRefs.push(p);
  }
  card.missingImgs = card.imgRefs.filter(ref => {
    const p = (source && source.type === "gh" ? card.repoDir : card.fsDir) + "/" + ref;
    return !knownImages.has(p);
  });
  return card;
}

/* 入库：rawItems=[{path, txt, dirHandle?}]；knownImages/localImgHandles 已先行填充 */
function ingest(rawItems){
  cards = rawItems.map(it => {
    const c = parseCard(it.txt, it.path);
    if (it.repoDir) c.repoDir = it.repoDir;
    c.missingImgs = c.imgRefs.filter(ref => {
      const p = (source && source.type === "gh" ? c.repoDir : c.fsDir) + "/" + ref;
      return !knownImages.has(p);
    });
    return c;
  });
  cards.sort((a,b)=> (a.yearKey==null?1:0)-(b.yearKey==null?1:0) || (a.yearKey||0)-(b.yearKey||0) || a.slug.localeCompare(b.slug));
  slugIndex = {}; for (const c of cards) if (!(c.slug in slugIndex)) slugIndex[c.slug] = c;
  backlinks = {};
  for (const c of cards) for (const sl of c.links)
    if (slugIndex[sl] && slugIndex[sl].uid !== c.uid) (backlinks[sl] = backlinks[sl] || []).push(c);
  chosen = new Set();
}

/* ================= 数据装载：本地 / GitHub ================= */
async function pickLocal(){
  if (!window.showDirectoryPicker){ setMsg("此浏览器不支持选择文件夹，请用电脑版 Edge/Chrome，或改用 GitHub 主库。"); return; }
  try {
    const root = await window.showDirectoryPicker({ mode:"read" });
    source = { type:"local", root };
    setMsg("正在读取本地卡片……");
    const items = [], images = new Set(); localImgHandles.clear();
    const cardRoot = await root.getDirectoryHandle("卡片");
    for await (const [, sh] of cardRoot.entries()){
      if (sh.kind !== "directory") continue;
      for await (const [, dh] of sh.entries()){
        if (dh.kind !== "directory") continue;
        let fh = null;
        try { fh = await dh.getFileHandle("卡片.md"); } catch(e){ continue; }
        const dirRel = "卡片/" + sh.name + "/" + dh.name;
        const txt = await (await fh.getFile()).text();
        items.push({ path: dirRel + "/卡片.md", txt });
        try {
          const imgDir = await dh.getDirectoryHandle("图");
          for await (const [, ih] of imgDir.entries()){
            if (ih.kind !== "file") continue;
            const p = dirRel + "/图/" + ih.name;
            images.add(p); localImgHandles.set(p, ih);
          }
        } catch(e){ /* 无 图/ 目录 */ }
      }
    }
    knownImages = images;
    finishLoad(items, "已连接本地文件夹：" + root.name);
  } catch(e){
    if (e.name !== "AbortError") setMsg("读取文件夹失败：" + e.message + "（确认选择的是「编年卡片」项目根目录）");
  }
}
async function loadGh(){
  if (!gh.repo || !gh.token){ $("ghPanel").open = true; ghStatus("先填仓库与令牌", false); return; }
  source = { type:"gh" };
  try {
    setMsg("正在读取 GitHub 卡片目录……");
    const bp = gh.base ? gh.base.replace(/\/+$/,"") + "/" : "";
    const treeRes = await fetch("https://api.github.com/repos/" + gh.repo + "/git/trees/" + (gh.branch||"main") + "?recursive=1", { headers: ghHeaders() });
    if (!treeRes.ok) throw new Error("目录读取失败 " + treeRes.status + "（检查仓库名/分支/令牌）");
    const tree = (await treeRes.json()).tree || [];
    knownImages = new Set();
    for (const x of tree){
      if (x.type !== "blob" || !x.path.startsWith(bp + "卡片/")) continue;
      if (x.path.endsWith("/卡片.md")) continue;
      if (x.path.includes("/图/")) knownImages.add(x.path);
    }
    const mdPaths = tree.filter(x => x.type==="blob" && x.path.startsWith(bp + "卡片/") && x.path.endsWith("/卡片.md")).map(x=>x.path);
    const items = [];
    for (let i=0;i<mdPaths.length;i++){
      setMsg("读取卡片 " + (i+1) + " / " + mdPaths.length + "……");
      try {
        const txt = await ghGetText(mdPaths[i]);
        const localRel = bp ? mdPaths[i].slice(bp.length) : mdPaths[i];
        items.push({ path: localRel, repoDir: mdPaths[i].replace(/\/卡片\.md$/,""), txt });
      } catch(e){}
    }
    finishLoad(items, "已连接 GitHub：" + gh.repo);
    ghStatus("连接成功", true);
  } catch(e){ setMsg(e.message); ghStatus(e.message, false); }
}
function finishLoad(items, statusText){
  if (!items.length){ setMsg("数据源里没有找到卡片（需要 卡片/系列/坐标/卡片.md 结构）。"); return; }
  ingest(items);
  setMsg("");
  $("srcStatus").textContent = statusText;
  $("srcStatus").classList.add("on");
  $("reloadBtn").style.display = "";
  $("emptyView").style.display = "none";
  renderHome();
  show("homeView");
  if (location.hash) {
    const sl = decodeURIComponent(location.hash.replace(/^#\/?/, ""));
    if (slugIndex[sl]) openCard(slugIndex[sl].uid);
  }
}

/* ================= Markdown 渲染（只覆盖库内实测语法，未识别原样转义） ================= */
function wikiHtml(slug, label){
  const c = slugIndex[slug];
  const text = label || slug;
  if (c) return '<button class="wikilink" data-slug="' + escAttr(slug) + '">' + esc(text) + "</button>";
  return '<span class="wikilink broken" title="库里还没有这张卡片——一个待写线索">' + esc(text) + "<em>待写</em></span>";
}
function inline(s){
  let t = esc(s);
  t = t.replace(/`([^`]+)`/g, (m,c)=>"<code>"+c+"</code>");
  t = t.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  t = t.replace(/\[\[([^\[\]|]+?)(?:\|([^\]]+))?\]\]/g, (m, sl, al)=>wikiHtml(sl.trim(), al?al.trim():""));
  return t;
}
function figureHtml(card, ref, alt, caption){
  const missing = card.missingImgs.includes(ref);
  const cap = caption ? inline(caption) : esc(alt || ref);
  return '<figure><img class="lazyimg' + (missing ? " missing" : "") + '" data-uid="' + escAttr(card.uid) + '" data-ref="' + escAttr(ref) + '" alt="' + escAttr(alt||ref) + '" title="' + escAttr((missing ? "图片文件缺失：" : "") + ref) + '"><figcaption>' + cap + (missing ? '（图片缺失）' : '') + '</figcaption></figure>';
}
function mdHtml(md, card){
  const lines = (md||"").replace(/\r/g,"").split("\n");
  const out = [];
  let i = 0;
  while (i < lines.length){
    const line = lines[i];
    const img = line.match(/^\s*!\[(.*?)\]\((.*?)\)\s*$/);
    if (img){
      const cap = []; let j = i + 1;
      while (j < lines.length && /^\s*>\s?/.test(lines[j])){ cap.push(lines[j].replace(/^\s*>\s?/,"")); j++; }
      out.push(figureHtml(card, img[2].trim().replace(/^\.\//,""), img[1], cap.join(" ").trim()));
      i = j; continue;
    }
    if (/^#{1,4}\s+/.test(line)){ out.push("<h4>" + inline(line.replace(/^#{1,4}\s+/,"")) + "</h4>"); i++; continue; }
    if (/^\s*>\s?/.test(line)){
      const q = [];
      while (i < lines.length && /^\s*>\s?/.test(lines[i])){ q.push(lines[i].replace(/^\s*>\s?/,"")); i++; }
      out.push("<blockquote>" + inline(q.join(" ")) + "</blockquote>"); continue;
    }
    if (/^\s*[-*]\s+/.test(line)){
      const items = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])){ items.push(lines[i].replace(/^\s*[-*]\s+/,"")); i++; }
      out.push("<ul>" + items.map(x=>"<li>"+inline(x)+"</li>").join("") + "</ul>"); continue;
    }
    if (!line.trim()){ i++; continue; }
    const p = [];
    while (i < lines.length && lines[i].trim() && !/^\s*[!>#]/.test(lines[i]) && !/^\s*[-*]\s/.test(lines[i])){ p.push(lines[i].trim()); i++; }
    if (p.length) out.push("<p>" + p.map(inline).join("<br>") + "</p>");
  }
  return out.join("\n");
}

/* ================= 图片懒加载 ================= */
async function resolveImgUrl(card, ref){
  const key = (source && source.type==="gh" ? card.repoDir : card.fsDir) + "/" + ref;
  if (imgUrlCache.has(key)) return imgUrlCache.get(key);
  let blob = null;
  if (source.type === "local"){
    const h = localImgHandles.get(key);
    if (!h) throw new Error("missing");
    blob = await h.getFile();
  } else {
    const res = await fetch(ghRawUrl(key), { headers: ghHeaders() });
    if (res.ok){ blob = await res.blob(); }
    else {
      // 回退 Contents API（base64，≤1MB）
      const j = await (await fetch(ghApiUrl(key), { headers: ghHeaders() })).json();
      if (!j.content) throw new Error("img404");
      const bin = atob(j.content.replace(/\n/g,""));
      const arr = new Uint8Array(bin.length);
      for (let i=0;i<bin.length;i++) arr[i] = bin.charCodeAt(i);
      blob = new Blob([arr]);
    }
  }
  const url = URL.createObjectURL(blob);
  imgUrlCache.set(key, url);
  return url;
}
function materializeImages(container){
  container.querySelectorAll("img.lazyimg").forEach(async img => {
    const card = cards.find(c => c.uid === img.dataset.uid);
    if (!card) return;
    try { img.src = await resolveImgUrl(card, img.dataset.ref); }
    catch(e){ img.classList.add("missing"); img.title = "图片缺失：" + img.dataset.ref; }
  });
}

/* ================= 视图切换 ================= */
function show(view){
  for (const v of ["emptyView","homeView","readerView","compareView"]) $(v).style.display = v === view ? "" : "none";
  $("homeBtn").style.display = (view === "readerView" || view === "compareView") ? "" : "none";
}
$("homeBtn").onclick = () => goHome();
function goHome(){
  curReaderUid = null;
  location.hash = "";
  renderHome();
  show("homeView");
}

/* ================= 书架 ================= */
function allTags(){
  const m = new Map();
  for (const c of cards) for (const t of c.tags) m.set(t, (m.get(t)||0)+1);
  return [...m.entries()].sort((a,b)=>b[1]-a[1] || a[0].localeCompare(b[0]));
}
function allSeries(){
  const m = new Map();
  for (const c of cards) for (const s of c.series) m.set(s, (m.get(s)||0)+1);
  return [...m.keys()].sort();
}
function cardHaystack(c){
  return [c.slug, c.overview, c.tags.join(" "), c.series.join(" "), c.sections.map(s=>s.title+" "+s.body).join(" ")].join("\n");
}
function filteredCards(){
  const q = $("searchInput").value.trim().toLowerCase();
  let list = cards.filter(c =>
    (fSeries === "全部" || c.series.includes(fSeries)) &&
    (!fTags.size || [...fTags].every(t => c.tags.includes(t))) &&
    (!q || cardHaystack(c).toLowerCase().includes(q))
  );
  const sort = $("sortSel").value;
  if (sort === "yearDesc") list = list.slice().sort((a,b)=>(b.yearKey==null?-1:b.yearKey)-(a.yearKey==null?-1:a.yearKey) || b.slug.localeCompare(a.slug));
  else if (sort === "updated") list = list.slice().sort((a,b)=>(b.update||"").localeCompare(a.update||""));
  return list;
}
function coordLine(c){
  const f = c.fields;
  return [f["年份"], f["地点"], f["对象"], f["范式"], f["时期"]].filter(Boolean).join(" · ");
}
function cardBadges(c){
  let h = "";
  if (c.placeholders.length) h += '<span class="badge info">待补×' + c.placeholders.length + "</span>";
  const broken = c.links.filter(sl => !slugIndex[sl]).length;
  if (broken) h += '<span class="badge warn">断链×' + broken + "</span>";
  if (c.missingImgs.length) h += '<span class="badge warn">缺图×' + c.missingImgs.length + "</span>";
  return h;
}
function renderHome(){
  // 系列筛选
  $("seriesFilter").innerHTML =
    '<span class="chip' + (fSeries==="全部"?" on":"") + '" data-s="全部">全部<span class="n">' + cards.length + "</span></span>" +
    allSeries().map(s => '<span class="chip' + (fSeries===s?" on":"") + '" data-s="' + escAttr(s) + '">' + esc(s) + '<span class="n">' + cards.filter(c=>c.series.includes(s)).length + "</span></span>").join("");
  $("seriesFilter").querySelectorAll(".chip").forEach(el => el.onclick = () => { fSeries = el.dataset.s; renderHome(); });
  // 标签筛选
  $("tagFilter").innerHTML = allTags().map(([t,n]) =>
    '<span class="chip' + (fTags.has(t)?" on":"") + '" data-t="' + escAttr(t) + '">' + esc(t) + '<span class="n">' + n + "</span></span>").join("") || '<span style="font-size:12px;color:var(--tx3);">（暂无标签）</span>';
  $("tagFilter").querySelectorAll(".chip").forEach(el => el.onclick = () => {
    const t = el.dataset.t;
    fTags.has(t) ? fTags.delete(t) : fTags.add(t);
    renderHome();
  });
  // 卡片网格
  const list = filteredCards();
  $("cardGrid").innerHTML = list.map(c =>
    '<div class="pcard">' +
      '<div style="display:flex;align-items:flex-start;gap:6px;"><input type="checkbox" class="cmp" title="加入对比" ' + (chosen.has(c.uid)?"checked":"") + '>' +
      '<div style="flex:1;min-width:0;"><div class="ttl" data-open="' + escAttr(c.uid) + '">' + esc(c.slug) + "</div>" +
      '<div class="meta">' + esc(coordLine(c)) + (c.series.length ? " · " + esc(c.series.join("/")) : "") + (c.update ? " · 更新 " + esc(c.update) : "") + "</div></div></div>" +
      '<div class="ov">' + esc(c.overview.replace(/\n/g," ") || "（无概述）") + "</div>" +
      '<div class="foot">' + c.tags.map(t=>'<span class="tag" data-tagjump="' + escAttr(t) + '">' + esc(t) + "</span>").join("") + cardBadges(c) + "</div>" +
    "</div>").join("") || '<div style="color:var(--tx3);font-size:13px;grid-column:1/-1;">没有符合筛选条件的卡片。</div>';
  $("cardGrid").querySelectorAll(".ttl").forEach(el => el.onclick = () => openCard(el.dataset.open));
  $("cardGrid").querySelectorAll(".tag").forEach(el => el.onclick = () => { fTags.add(el.dataset.tagjump); renderHome(); window.scrollTo(0,0); });
  $("cardGrid").querySelectorAll(".cmp").forEach(box => box.onchange = () => {
    const uid = box.closest(".pcard").querySelector(".ttl").dataset.open;
    if (box.checked){ if (chosen.size >= 2){ box.checked = false; return; } chosen.add(uid); }
    else chosen.delete(uid);
    $("cmpN").textContent = chosen.size;
    $("cmpGoBtn").disabled = chosen.size !== 2;
  });
  $("cmpN").textContent = chosen.size;
  $("cmpGoBtn").disabled = chosen.size !== 2;
  renderHealth();
}
function renderHealth(){
  const broken = new Map();       // slug -> [cards]
  const missImg = [];
  const todo = [];
  for (const c of cards){
    for (const sl of c.links) if (!slugIndex[sl]){ (broken.get(sl) || broken.set(sl, []).get(sl)).push(c); }
    if (c.missingImgs.length) missImg.push(c);
    if (c.placeholders.length) todo.push(c);
  }
  const total = broken.size + missImg.length + todo.length;
  $("healthSummary").textContent = "数据体检：" + (total ? "发现 " + broken.size + " 个断链 / " + missImg.length + " 张缺图 / " + todo.length + " 张有待补" : "全部健康：无断链、无缺图、无待补");
  let h = "";
  if (broken.size){
    h += '<div style="margin-top:6px;color:var(--warn);">断链（缺失的卡片 = 待写线索）：</div>';
    for (const [sl, cs] of broken){
      h += '<div class="hrow">→ [[' + esc(sl) + "]]　被引于 " +
        cs.map(c => '<button class="linklike" data-open="' + escAttr(c.uid) + '">' + esc(c.slug) + "</button>").join("、") + "</div>";
    }
  }
  if (missImg.length){
    h += '<div style="margin-top:6px;color:var(--warn);">缺图（引用了但 图/ 里没有）：</div>';
    for (const c of missImg){
      h += '<div class="hrow"><button class="linklike" data-open="' + escAttr(c.uid) + '">' + esc(c.slug) + "</button>：" + c.missingImgs.map(esc).join("、") + "</div>";
    }
  }
  if (todo.length){
    h += '<div style="margin-top:6px;color:var(--tx2);">待补小节：</div>';
    for (const c of todo){
      h += '<div class="hrow"><button class="linklike" data-open="' + escAttr(c.uid) + '">' + esc(c.slug) + "</button>：" + esc(c.placeholders.join("、")) + "</div>";
    }
  }
  $("healthBody").innerHTML = h;
  $("healthBody").querySelectorAll("[data-open]").forEach(b => b.onclick = () => openCard(b.dataset.open));
}
$("searchInput").addEventListener("input", renderHome);
$("sortSel").addEventListener("change", renderHome);
$("cmpGoBtn").onclick = () => openCompare();

/* ================= 阅读视图 ================= */
function openCard(uid){
  const c = cards.find(x => x.uid === uid);
  if (!c) return;
  curReaderUid = uid;
  location.hash = "/" + encodeURIComponent(c.slug);
  let h = "<h2>" + esc(c.slug) + "</h2>";
  h += '<div class="rmeta">' + esc(coordLine(c)) +
    (c.series.length ? " · <b>" + esc(c.series.join("/")) + "</b>" : "") +
    (c.update ? " · 更新于 " + esc(c.update) : "") + "<br>" +
    c.tags.map(t=>'<span class="tag" data-tagjump="' + escAttr(t) + '">' + esc(t) + "</span>").join("") +
    '　<label style="font-size:11.5px;color:var(--tx3);"><input type="checkbox" id="cmpAdd" style="width:auto;vertical-align:-2px;"> 加入对比</label></div>';
  h += "<h3>概述</h3><div>" + mdHtml(c.overview || "（待补）", c) + "</div>";
  for (const s of c.sections) h += "<h3>" + esc(s.title) + (s.placeholder ? ' <span class="badge info">待补</span>' : "") + "</h3><div>" + mdHtml(s.body || "（待补）", c) + "</div>";
  const bl = backlinks[c.slug] || [];
  h += '<div class="backlinks"><h3 style="border:none;padding:0;">反向链接（' + bl.length + "）</h3>";
  h += bl.length ? bl.map(b => '<div class="bl"><button class="wikilink backlink" data-slug="' + escAttr(b.slug) + '">' + esc(b.slug) + "</button> <span style='color:var(--tx3);'>" + esc((b.overview||"").slice(0,48)) + "</span></div>").join("")
                 : '<div style="font-size:12.5px;color:var(--tx3);">还没有卡片链接到这里。</div>';
  h += "</div>";
  $("readerBox").innerHTML = h;
  $("readerBox").querySelectorAll(".wikilink[data-slug]").forEach(b => b.onclick = () => {
    const target = slugIndex[b.dataset.slug];
    if (target) openCard(target.uid);
  });
  $("readerBox").querySelectorAll(".tag[data-tagjump]").forEach(b => b.onclick = () => { fTags.add(b.dataset.tagjump); goHome(); });
  const addBox = $("cmpAdd");
  addBox.checked = chosen.has(c.uid);
  addBox.onchange = () => {
    if (addBox.checked){ if (chosen.size >= 2){ addBox.checked = false; alert("对比最多选两张，先在书架取消一张。"); return; } chosen.add(c.uid); }
    else chosen.delete(c.uid);
  };
  show("readerView");
  window.scrollTo(0,0);
  materializeImages($("readerBox"));
}

/* ================= 对比视图 ================= */
function openCompare(){
  const pair = [...chosen].map(uid => cards.find(c => c.uid === uid)).filter(Boolean);
  if (pair.length !== 2) return;
  const sameSeries = pair[0].series.some(s => pair[1].series.includes(s));
  let h = "";
  if (sameSeries){
    // 同系列：以两张卡的小节并集（保序）逐行对齐
    const titles = [];
    for (const c of pair) for (const s of c.sections) if (!titles.includes(s.title)) titles.push(s.title);
    const secMap = c => { const m = {}; for (const s of c.sections) m[s.title] = s; return m; };
    const maps = pair.map(secMap);
    h += cmpHead(pair[0]) + cmpHead(pair[1]);
    h += '<div style="grid-column:1/-1;">' + titles.map(t =>
      '<div class="cmprow"><div class="cell"><h4>' + esc(t) + '</h4>' +
        cellBody(maps[0][t], pair[0]) + '</div><div class="cell"><h4>' + esc(t) + '</h4>' + cellBody(maps[1][t], pair[1]) + '</div></div>').join("") +
        '<div class="cmprow"><div class="cell"><h4>概述</h4>' + cellBody({body:pair[0].overview,placeholder:isPlaceholder(pair[0].overview)}, pair[0]) + '</div>' +
        '<div class="cell"><h4>概述</h4>' + cellBody({body:pair[1].overview,placeholder:isPlaceholder(pair[1].overview)}, pair[1]) + '</div></div></div>';
  } else {
    h += pair.map(c => cmpColFull(c)).join("");
  }
  $("cmpBox").innerHTML = h;
  $("cmpBox").querySelectorAll("[data-slug]").forEach(b => b.onclick = () => { const t = slugIndex[b.dataset.slug]; if (t) openCard(t.uid); });
  $("cmpBox").querySelectorAll("h2[data-open]").forEach(b => b.onclick = () => openCard(b.dataset.open));
  show("compareView");
  window.scrollTo(0,0);
  materializeImages($("cmpBox"));
}
function cmpHead(c){
  return '<div class="cmpcol"><h2 data-open="' + escAttr(c.uid) + '">' + esc(c.slug) + "</h2>" +
    '<div class="cmeta">' + esc(coordLine(c)) + (c.update ? " · 更新 " + esc(c.update) : "") + "</div></div>";
}
function cellBody(sec, card){
  if (!sec) return '<p style="color:var(--tx3);">—</p>';
  return (sec.placeholder ? '<p style="color:var(--tx3);">（待补）</p>' : mdHtml(sec.body, card));
}
function cmpColFull(c){
  let h = '<div class="cmpcol"><h2 data-open="' + escAttr(c.uid) + '">' + esc(c.slug) + "</h2>" +
    '<div class="cmeta">' + esc(coordLine(c)) + " · " + esc(c.series.join("/")) + "</div>" +
    "<h4>概述</h4>" + cellBody({body:c.overview,placeholder:isPlaceholder(c.overview)}, c);
  for (const s of c.sections) h += "<h4>" + esc(s.title) + "</h4>" + cellBody(s, c);
  return h + "</div>";
}

/* ================= 接线 ================= */
$("pickBtn").onclick = pickLocal;
$("emptyPick").onclick = pickLocal;
$("emptyGh").onclick = () => { $("ghPanel").open = true; $("ghRepo").focus(); };
$("reloadBtn").onclick = () => { if (source.type === "gh") loadGh(); else pickLocal(); };
$("ghSave").onclick = () => {
  gh.repo = $("ghRepo").value.trim();
  gh.branch = $("ghBranch").value.trim() || "main";
  gh.base = $("ghBase").value.trim();
  gh.token = $("ghToken").value.trim();
  try { localStorage.setItem("nb-gh", JSON.stringify(gh)); } catch(e){}
  fillGhForm();
  loadGh();
};
fillGhForm();
show("emptyView");

/* 已配置 GitHub 则自动连接（只读，手机上打开网址即用） */
if (gh.repo && gh.token) loadGh();
