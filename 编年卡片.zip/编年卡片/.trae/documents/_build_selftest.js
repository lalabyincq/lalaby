/* 生成 _selftest_v4.html：在 阅读卡片.html 中注入 假FS/假IDB 夹具 + 断言运行器 */
const fs = require("fs");
const path = require("path");
const root = path.join(__dirname, "..", "..");
let html = fs.readFileSync(path.join(root, "阅读卡片.html"), "utf8");

const cards = [
  ["编年", "-3000-埃及"],
  ["编年", "1200-杭州"],
  ["编年", "1700-阿姆斯特丹"],
  ["交互", "1966-ELIZA"],
  ["交互", "2007-iPhone"],
  ["梵高研究", "1888-阿尔勒-夜间咖啡馆"]
].map(([se, slug]) => ({
  se, slug,
  md: fs.readFileSync(path.join(root, "卡片", se, slug, "卡片.md"), "utf8")
}));

const dataTag = `<script>window.__CARDS = ${JSON.stringify(cards)};</script>`;
const fixture = `
<script>
/* ============ v4 自测夹具（仅存在于自测页面） ============ */
window.__errs = [];
addEventListener("error", e => window.__errs.push("error: " + (e.message || e)));
addEventListener("unhandledrejection", e => window.__errs.push("rej: " + ((e.reason && e.reason.message) || e.reason)));
try { localStorage.removeItem("nb-gh"); } catch(e){}

/* 内存版 indexedDB（避免污染/依赖真实库；页面只用 kv 单对象仓） */
window.indexedDB = (function(){
  const store = new Map();
  function makeReq(result){
    const r = { result, onsuccess:null, onerror:null };
    queueMicrotask(() => { try { r.onsuccess && r.onsuccess({ target:r }); } catch(e){} });
    return r;
  }
  function txn(){
    const tx = { oncomplete:null, onerror:null, objectStore(){ return {
      get(k){ return makeReq(store.has(k) ? store.get(k) : null); },
      put(v,k){
        store.set(k, v);
        const r = makeReq(undefined);
        const fire = r.onsuccess;
        r.onsuccess = ev => { fire && fire(ev); queueMicrotask(() => tx.oncomplete && tx.oncomplete()); };
        return r;
      }
    }; } };
    return tx;
  }
  return {
    open(){
      const q = { result:{ transaction:() => txn(), createObjectStore(){} }, onupgradeneeded:null, onsuccess:null, onerror:null };
      queueMicrotask(() => { q.onupgradeneeded && q.onupgradeneeded(); q.onsuccess && q.onsuccess(); });
      return q;
    }
  };
})();

/* 内存版 File System Access（句柄对象，不进结构化克隆） */
window.__writes = [];
function mkErr(){ const e = new Error("not found"); e.name = "NotFoundError"; return e; }
function mkFile(p, data){
  return {
    kind:"file", name:p.split("/").pop(),
    async getFile(){ return { text: async() => (typeof data === "string" ? data : await data.text()) }; },
    async createWritable(){ return { async write(d){ data = d; window.__writes.push(p); }, async close(){} }; }
  };
}
function mkDir(p){
  const dirs = new Map(), files = new Map();
  return {
    kind:"directory", name:p ? p.split("/").pop() : "root", _path:p,
    async getDirectoryHandle(n, o){
      if (!dirs.has(n)){ if (!o || !o.create) throw mkErr(); dirs.set(n, mkDir(p ? p+"/"+n : n)); }
      return dirs.get(n);
    },
    async getFileHandle(n, o){
      if (!files.has(n)){ if (!o || !o.create) throw mkErr(); files.set(n, mkFile(p ? p+"/"+n : n, "")); }
      return files.get(n);
    },
    entries(){ return (function*(){ for (const x of dirs) yield x; for (const x of files) yield x; })(); }
  };
}
window.__root = mkDir("");
window.__seed = (async() => {
  for (const c of window.__CARDS){
    let d = window.__root;
    for (const seg of ["卡片", c.se, c.slug]) d = await d.getDirectoryHandle(seg, { create:true });
    const f = await d.getFileHandle("卡片.md", { create:true });
    const w = await f.createWritable(); await w.write(c.md); await w.close();
  }
})();
window.showDirectoryPicker = async () => window.__root;
</script>
`;

const runner = `
<script>
/* ============ v4 自测断言运行器 ============ */
(async function(){
  const R = [];
  const ok = (n, c, extra) => R.push({ n, pass:!!c, extra:(extra===undefined?"":String(extra)) });
  const tick = (ms) => new Promise(r => setTimeout(r, ms || 40));
  window.confirm = () => true;
  try {
    await window.__seed;
    await readLocalRoot(window.__root);
    await tick();

    ok("书架装载6卡", cards.length === 6, cards.length);
    ok("新增按钮可见", $("newCardBtn").style.display !== "none", $("newCardBtn").style.display);
    ok("书架网格6张", document.querySelectorAll("#cardGrid .pcard").length === 6);
    ok("测试连接按钮存在", !!$("ghTestBtn"));
    ok("编辑视图初始隐藏", $("editView").style.display === "none");

    /* 新建卡片 */
    startNewCard();
    await tick();
    ok("进入编辑视图", $("editView").style.display !== "none" && $("homeView").style.display === "none" && $("emptyView").style.display === "none");
    const ax = k => document.querySelector('#axes input[data-k="'+k+'"]');
    ax("年份").value = "2026"; ax("地点").value = "测试城";
    $("overview").value = "自测卡片概述内容";
    tags.push("自测标签"); renderTags();
    $("dimText").value = "政治维度自测文字";
    $("links").value = "参见 [[1200-杭州]]：自测反链";
    $("source").value = "自测来源";
    saveCurDim(); updatePreview();
    const built = buildMarkdown();
    ok("生成MD含更新日期", /更新:\\d{4}-\\d{2}-\\d{2}/.test(built.md));
    ok("生成MD含标签YAML", built.md.includes("标签:\\n  - 自测标签"), JSON.stringify(built.md.match(/标签:[^\\n]*/)));
    ok("生成MD含系列", built.md.includes("系列:\\n  - 编年卡片"));
    ok("预览同步", $("preview").textContent.includes("自测卡片概述内容"));

    await saveSlice();
    await tick(); await tick();
    ok("新建保存后在阅读视图", $("readerView").style.display !== "none");
    ok("阅读标题=新卡slug", (($("readerBox").querySelector("h2")||{}).textContent) === "2026-测试城", ($("readerBox").querySelector("h2")||{}).textContent);
    ok("假FS写入卡片.md", window.__writes.includes("卡片/编年/2026-测试城/卡片.md"), window.__writes.join(" | "));
    ok("刷新后共7卡", cards.length === 7, cards.length);

    /* 编辑已有卡片：1200-杭州 */
    const hz = cards.find(c => c.slug === "1200-杭州");
    await startEditCard(hz.uid);
    await tick();
    ok("编辑横幅显示", $("editBanner").style.display !== "none");
    ok("杭州标签回填(≥4)", tags.length >= 4, tags.length + ":" + tags.join(","));
    ok("政治维度回填", (dimValues["政治"] || "").includes("君主官僚"), (dimValues["政治"]||"").slice(0,20));
    ok("年份回填1195-1205", document.querySelector('#axes input[data-k="年份"]').value === "1195-1205", document.querySelector('#axes input[data-k="年份"]').value);
    ok("保存按钮覆盖文案", $("saveBtn").textContent === "保存修改（覆盖原文件）", $("saveBtn").textContent);
    $("overview").value = $("overview").value + "【测试修改】";
    updatePreview();
    await saveSlice();
    await tick(); await tick();
    ok("编辑保存后回到该卡阅读", $("readerView").style.display !== "none" && (($("readerBox").querySelector("h2")||{}).textContent) === "1200-杭州");
    const dH = await walkDir(window.__root, "卡片/编年/1200-杭州");
    const fH = await dH.getFileHandle("卡片.md");
    const mdH = await (await fH.getFile()).text();
    ok("覆盖内容已落盘", mdH.includes("【测试修改】"));
    const bl = $("readerBox").querySelectorAll(".backlinks .bl").length;
    ok("杭州反链渲染(≥2)", bl >= 2, "bl=" + bl);
    ok("新卡出现在杭州反链", $("readerBox").querySelectorAll(".backlinks .bl .wikilink").length >= 2);

    /* 返回：表单有内容也应回到阅读页（confirm 已桩为 true） */
    await leaveEditor();
    await tick();
    ok("离开编辑回到杭州阅读页", $("readerView").style.display !== "none" && (($("readerBox").querySelector("h2")||{}).textContent) === "1200-杭州");

    /* 回归：时间轴/矩阵 */
    renderTimeline();
    ok("时间轴7项", document.querySelectorAll("#timelineBox .item").length === 7);
    renderMatrix();
    ok("矩阵7行", document.querySelectorAll("#matrixBox tbody tr").length === 7);
    goHome();
    await tick();
    ok("书架网格7张", document.querySelectorAll("#cardGrid .pcard").length === 7);
    ok("回到书架后编辑视图隐藏", $("editView").style.display === "none");
  } catch(e){
    window.__errs.push("runner: " + e.message + "\\n" + (e.stack || ""));
  }
  if (window.__errs.length) R.unshift({ n:"运行期无错误", pass:false, extra:window.__errs.join(" || ") });
  window.__test = { results:R, errs:window.__errs };
  const fails = R.filter(r => !r.pass);
  document.documentElement.setAttribute("data-selftest", "done");
  document.documentElement.setAttribute("data-fails", String(fails.length));
  document.title = fails.length ? ("SELFTEST FAIL " + fails.length) : "SELFTEST OK";
})();
</script>
`;

const idx = html.indexOf("<script>");
if (idx < 0) throw new Error("no script tag");
html = html.slice(0, idx) + dataTag + fixture + html.slice(idx);
html = html.replace("</body>", runner + "</body>");
fs.writeFileSync(path.join(__dirname, "_selftest_v4.html"), html, "utf8");
console.log("written _selftest_v4.html, cards:", cards.length);
