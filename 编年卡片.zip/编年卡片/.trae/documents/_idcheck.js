const fs = require("fs");
const h = fs.readFileSync(__dirname + "/../../阅读卡片.html", "utf8");
const ids = new Set([...h.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
const refs = new Set([...h.matchAll(/\$\("([A-Za-z0-9_]+)"\)/g)].map(m => m[1]));
const missing = [...refs].filter(r => !ids.has(r));
console.log("ids:", ids.size, "refs:", refs.size);
console.log("missing:", missing.length ? missing.join(", ") : "(none)");
